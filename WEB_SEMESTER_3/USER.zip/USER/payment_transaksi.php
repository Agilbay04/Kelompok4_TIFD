<?php 
    
    require_once "assets/includes/header_dashboard_plg.php";
    
    require_once "assets/includes/connection.php";

?>







<?php require_once "assets/includes/footer.php";?>
<?php require_once "assets/includes/footer_modal.php";?>
<?php require_once "assets/includes/footer_javascript.php";?>
<script src="assets/javascript/script_error_catch.js"></script>
<script src="assets/javascript/script_dashboard_profile.js"></script>
<?php require_once "assets/includes/footer_close.php"?>