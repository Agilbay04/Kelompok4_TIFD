    <!-- Footer Start -->
    <footer class="bg-dark p-2">
        <p class="text-center text-white m-0"> &copy; MaCo Team Production 2019 </p>
    </footer>
    <!-- Footer End -->
