<?php

    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "new1";
    $conn = mysqli_connect($host, $username, $password, $database);

    //Check connection
?>